# TLDRPress

TLDRPress is a lightweight WordPress plugin for generating AI-powered TL;DR summaries for blog posts, publishers, news sites, and editorial teams.

Summaries are generated in the WordPress admin and stored permanently in post meta. The plugin never calls AI services during frontend page loads.

## Features

- Generate summaries with the OpenAI API.
- Manual generation from the post editor.
- Optional auto-generation when a post is published.
- Bulk generation tool with AJAX batch processing.
- Bullet or paragraph summaries.
- Short, medium, or long summary lengths.
- Editable saved summaries.
- Automatic frontend display with configurable placement.
- Manual display with `[tldrpress]`.
- Gutenberg block: **TLDRPress Summary**.
- Elementor widget: **TLDRPress Summary**.
- REST endpoint for saved summaries.
- Responsive, minimal frontend summary box.
- Dark mode compatible CSS.
- Provider abstraction for future Anthropic Claude, Gemini, Ollama, or local AI support.

## Requirements

- WordPress 6.2 or higher.
- PHP 7.4 or higher.
- An OpenAI API key.

## Installation

1. Upload the plugin folder to `wp-content/plugins/tldrpress`, or upload the plugin ZIP through **Plugins > Add New > Upload Plugin**.
2. Activate **TLDRPress**.
3. Go to **TLDRPress > Settings**.
4. Add your OpenAI API key.
5. Choose your preferred model, summary type, summary length, and display settings.

## Basic Usage

Open a post in the WordPress editor. In the **TLDRPress Summary** meta box, choose the summary type and length, then click **Generate Summary**.

The generated summary is saved as post meta and can be edited manually before saving the post.

## Shortcode

Display the current post summary:

```text
[tldrpress]
```

Display a specific post summary:

```text
[tldrpress id="123"]
```

For full layout control, disable **Enable automatic frontend display** in **TLDRPress > Settings** and place the shortcode wherever you want the summary to appear.

## Gutenberg Block

Add the **TLDRPress Summary** block to a post, page, template, or block-based layout. The block renders the saved summary for the current post by default.

## Elementor Widget

If Elementor is active, TLDRPress registers a **TLDRPress Summary** widget. Use it inside Elementor templates or single post layouts to control placement and styling.

## Bulk Generation

Go to **TLDRPress > Bulk Generate** to generate summaries for existing posts.

Available modes:

- Generate only missing summaries.
- Regenerate all summaries.
- Generate summaries for all existing posts.

Bulk generation runs in small AJAX batches to avoid server timeouts.

## Frontend Styling

The frontend box uses stable CSS classes for theme or builder overrides:

```css
.tldrpress-box {}
.tldrpress-header {}
.tldrpress-icon {}
.tldrpress-content {}
.tldrpress-content ul {}
.tldrpress-content li {}
```

You can add overrides in your theme, WordPress **Additional CSS**, Elementor custom CSS, or a site-specific plugin.

## REST API

Retrieve a saved summary:

```text
/wp-json/tldrpress/v1/summary/{post_id}
```

Example response:

```json
{
  "post_id": 123,
  "summary": "Saved summary text",
  "type": "bullets",
  "length": "medium",
  "has_tldr": true
}
```

## Developer Hooks

Replace the AI provider:

```php
add_filter( 'tldrpress_ai_provider', function ( $provider, $settings ) {
	return $provider;
}, 10, 2 );
```

Filter generation arguments:

```php
add_filter( 'tldrpress_generation_args', function ( $args, $post ) {
	return $args;
}, 10, 2 );
```

Filter the OpenAI model:

```php
add_filter( 'tldrpress_openai_model', function ( $model, $args ) {
	return $model;
}, 10, 2 );
```

Filter the OpenAI request body:

```php
add_filter( 'tldrpress_openai_request_body', function ( $body, $args ) {
	return $body;
}, 10, 2 );
```

Run code after a summary is generated:

```php
add_action( 'tldrpress_summary_generated', function ( $post_id, $summary, $type, $length ) {
	// Sync, log, or extend summary data here.
}, 10, 4 );
```

Filter the frontend summary box HTML:

```php
add_filter( 'tldrpress_summary_box_html', function ( $html, $post_id, $summary, $type ) {
	return $html;
}, 10, 4 );
```

## Privacy

When a summary is generated, TLDRPress sends the post content to OpenAI for processing. The generated summary is stored in your WordPress database as post meta. TLDRPress does not send visitor data to OpenAI and does not call OpenAI on frontend page loads.

Site owners are responsible for reviewing OpenAI's data usage policies and updating their privacy policy as needed.

## License

GPL-2.0-or-later.
