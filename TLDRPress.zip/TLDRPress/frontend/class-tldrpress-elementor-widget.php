<?php
/**
 * Elementor widget.
 *
 * @package TLDRPress
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Elementor summary widget.
 */
class TLDRPress_Elementor_Widget extends \Elementor\Widget_Base {
	/**
	 * Settings.
	 *
	 * @var TLDRPress_Settings
	 */
	private $settings;

	/**
	 * Constructor.
	 *
	 * @param TLDRPress_Settings $settings Settings.
	 * @param array|null         $data Data.
	 * @param array|null         $args Args.
	 */
	public function __construct( TLDRPress_Settings $settings, $data = array(), $args = null ) {
		$this->settings = $settings;
		parent::__construct( $data, $args );
	}

	/**
	 * Widget name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'tldrpress_summary';
	}

	/**
	 * Widget title.
	 *
	 * @return string
	 */
	public function get_title() {
		return __( 'TLDRPress Summary', 'tldrpress' );
	}

	/**
	 * Widget icon.
	 *
	 * @return string
	 */
	public function get_icon() {
		return 'eicon-post-excerpt';
	}

	/**
	 * Widget categories.
	 *
	 * @return array
	 */
	public function get_categories() {
		return array( 'general' );
	}

	/**
	 * Render widget.
	 *
	 * @return void
	 */
	protected function render() {
		$frontend = new TLDRPress_Frontend( $this->settings, false );
		echo $frontend->render_summary( get_the_ID() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
