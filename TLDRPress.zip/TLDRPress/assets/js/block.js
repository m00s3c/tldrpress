(function (blocks, element, blockEditor, components, i18n) {
	'use strict';

	var el = element.createElement;
	var useBlockProps = blockEditor.useBlockProps;
	var TextControl = components.TextControl;
	var __ = i18n.__;

	blocks.registerBlockType('tldrpress/summary', {
		title: __('TLDRPress Summary', 'tldrpress'),
		icon: 'editor-ul',
		category: 'widgets',
		attributes: {
			postId: {
				type: 'number',
				default: 0
			}
		},
		edit: function (props) {
			return el(
				'div',
				useBlockProps({ className: 'tldrpress-block-placeholder' }),
				el('strong', null, __('TLDRPress Summary', 'tldrpress')),
				el('p', null, __('Displays the saved TL;DR summary for this post.', 'tldrpress')),
				el(TextControl, {
					label: __('Optional post ID', 'tldrpress'),
					type: 'number',
					value: props.attributes.postId || '',
					onChange: function (value) {
						props.setAttributes({ postId: parseInt(value, 10) || 0 });
					}
				})
			);
		},
		save: function () {
			return null;
		}
	});
})(window.wp.blocks, window.wp.element, window.wp.blockEditor, window.wp.components, window.wp.i18n);
