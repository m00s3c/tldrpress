<?php
/**
 * Gutenberg block.
 *
 * @package TLDRPress
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Block registration.
 */
class TLDRPress_Blocks {
	/**
	 * Settings.
	 *
	 * @var TLDRPress_Settings
	 */
	private $settings;

	/**
	 * Constructor.
	 *
	 * @param TLDRPress_Settings $settings Settings.
	 */
	public function __construct( TLDRPress_Settings $settings ) {
		$this->settings = $settings;
		add_action( 'init', array( $this, 'register_block' ) );
	}

	/**
	 * Register dynamic block.
	 *
	 * @return void
	 */
	public function register_block() {
		wp_register_script(
			'tldrpress-block',
			TLDRPRESS_URL . 'assets/js/block.js',
			array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n' ),
			TLDRPRESS_VERSION,
			true
		);

		register_block_type(
			'tldrpress/summary',
			array(
				'editor_script'   => 'tldrpress-block',
				'render_callback' => array( $this, 'render_block' ),
				'attributes'      => array(
					'postId' => array(
						'type'    => 'number',
						'default' => 0,
					),
				),
			)
		);
	}

	/**
	 * Render block.
	 *
	 * @param array $attributes Attributes.
	 * @return string
	 */
	public function render_block( $attributes ) {
		$post_id  = ! empty( $attributes['postId'] ) ? absint( $attributes['postId'] ) : get_the_ID();
		$frontend = new TLDRPress_Frontend( $this->settings, false );

		return $frontend->render_summary( $post_id );
	}
}
